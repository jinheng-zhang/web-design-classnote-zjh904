import os
import shutil

from PIL import Image

BASE = r"D:\univercity\web design"
IMG_DIR = os.path.join(BASE, "image")
BACKUP = os.path.join(BASE, ".workbuddy", "backup", "image")
os.makedirs(BACKUP, exist_ok=True)

for name in ("1.jpg", "2.jpg"):
    path = os.path.join(IMG_DIR, name)
    shutil.copy2(path, os.path.join(BACKUP, name))
    with Image.open(path) as im:
        w, h = im.size
        target_w = int(h * 3 / 2)
        if target_w < w:
            x = (w - target_w) // 2
            cropped = im.crop((x, 0, x + target_w, h))
            cropped.save(path, "JPEG", quality=90)
            print(name, f"{w}x{h} -> {target_w}x{h}")
        else:
            print(name, "skipped", f"{w}x{h}")
