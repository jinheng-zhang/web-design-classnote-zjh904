---
name: commit-to-gitee
description: 把本项目（高级网页设计课堂实践，D:\univercity\web design）的改动提交并推送到 Gitee 仓库 neusoft_wangyao_jsj/webdesign004project。当用户说"提交项目"、"提交到gitee"、"推送到gitee"、"把作业提交上去"、"commit 并 push"、"更新仓库"时使用。已内置仓库地址与认证方式，无需用户重复提供。
---

# 提交项目到 Gitee

把本项目的改动提交并推送到课程 Gitee 仓库。

## 项目信息（已固定，直接用，不要问用户）

| 项目 | 值 |
| --- | --- |
| 本地目录 | `D:\univercity\web design`（Git Bash 写作 `/d/univercity/web design`） |
| 分支 | `main` |
| 仓库地址 | `https://gitee.com/neusoft_wangyao_jsj/webdesign004project.git` |
| 认证方式 | 私人令牌，以 `oauth2` 作为用户名 |

带认证的远程地址（本仓库 remote 已配置好，通常不需要重设）：

```
https://oauth2:<PRIVATE_TOKEN>@gitee.com/neusoft_wangyao_jsj/webdesign004project.git
```

私人令牌存放位置：`.git/config` 中 `remote.origin.url`。**不要在对话里回显完整令牌**，也不要把令牌写进任何会被提交的文件。

## 执行流程

### 第 1 步：进入目录并确认状态

```bash
cd "/d/univercity/web design"
git status --short
git log --oneline -3
```

- `git status --short` 为空 → 告知用户"当前没有需要提交的改动"。此时仍可检查本地是否领先远端（见第 5 步），有未推送的提交就补推，否则结束。
- 有改动 → 继续。

### 第 2 步：确认 remote 配置正确

```bash
git remote -v
```

- 没有 `origin` → 添加（把令牌替换为 `.git/config` 里已有的值，或请用户提供）：
  ```bash
  git remote add origin "https://oauth2:<TOKEN>@gitee.com/neusoft_wangyao_jsj/webdesign004project.git"
  ```
- 有 `origin` 但地址不含令牌 → 更新。注意：**仓库目录内可能有多个子目录/子模块概念的文件，改动 remote 前先确认没有其他 remote 冲突**：
  ```bash
  git remote set-url origin "https://oauth2:<TOKEN>@gitee.com/neusoft_wangyao_jsj/webdesign004project.git"
  ```

### 第 3 步：拉取远端，避免历史分叉

```bash
git fetch origin
```

**重要坑**：本环境下 `git fetch origin` 有时只写入 `FETCH_HEAD` 而不创建 `refs/remotes/origin/main`，导致后续 `git diff origin/main` 报 `Not a valid object name`。若出现该情况，直接读 `FETCH_HEAD` 或用显式 refspec：

```bash
git fetch origin "refs/heads/main:refs/remotes/origin/main"
```

然后对比：

```bash
git rev-parse HEAD; cat .git/FETCH_HEAD | head -1
```

若远端有本地没有的提交，先合并再推：

```bash
git merge origin/main --allow-unrelated-histories
```

**首次克隆式合并的注意点**：远端可能已有老师/同学提交的**同名不同内容文件**（本项目就遇到过 `index1.html` 冲突，远端是同学的作业版本）。处理原则：

- 冲突文件优先保留**用户自己**的版本。
- 对方版本内容**不要直接丢弃**，另存为 `xxx_remote_backup.html` 之类的文件保留，并在提交信息里说明。
- 合并后检查文件里是否残留 `<<<<<<<`、`=======`、`>>>>>>>` 标记，必须全部清除。

清理冲突标记可用：

```bash
grep -rn "^<<<<<<<\|^=======$\|^>>>>>>>" . --include="*.html" --include="*.css"
```

### 第 4 步：暂存并提交

```bash
git add -A
git status --short
```

生成**中文**提交信息：第一行摘要（50 字内，动词开头），需要时空一行后用 `-` 列要点。

**Windows 关键坑**：提交信息临时文件**必须放在仓库目录内**，不能用 `/tmp`（Git for Windows 解析不到，会报 `fatal: could not read log file`）。

```bash
cat > .git-commit-msg.tmp <<'EOF'
提交摘要写在这里

- 第一条说明
- 第二条说明
EOF
git commit -F .git-commit-msg.tmp
rm -f .git-commit-msg.tmp
```

### 第 5 步：推送

```bash
git push origin main
```

- 推送命令在部分环境下会被超时中断。**优先用后台方式执行**，或加大超时时间：
  ```bash
  git push origin main
  ```
  看到 `remote: Powered by GITEE.COM` 和 `xxx..yyy  main -> main` 即成功。
- 若报 `! [rejected] ... non-fast-forward`：说明远端有新提交，回到第 3 步 fetch + merge，**禁止 `git push -f`**。
- 若报认证 403 / `The token username invalid`：说明 remote 地址里的用户名不对。Gitee 必须用 `oauth2:<TOKEN>` 形式，不能用 `用户名:<TOKEN>` 或裸令牌。

### 第 6 步：汇报

```bash
git log --oneline -3
git status -sb
```

用中文简短总结：提交哈希与摘要、涉及文件、推送结果（本地与远端是否一致）。

## 安全红线

- **禁止** `git push -f` / `git push --force`，会覆盖老师或同学的历史。
- **禁止** `git reset --hard`、`git clean -fd`。
- **禁止**把私人令牌写进代码文件、README、`.gitignore` 之外的任何被跟踪文件。
- **禁止** `/tmp` 作为提交信息临时文件路径（见第 4 步）。
- 遇到冲突时保留用户自己的版本，对方版本另存备份，不要静默丢弃。
- 令牌一旦泄露（例如未经 oauth2 前缀出现在日志里），提醒用户去 Gitee 后台重置。

## 常见问题速查

| 现象 | 原因与处理 |
| --- | --- |
| `The token username invalid` + 403 | remote 地址用户名不对，必须 `oauth2:<TOKEN>` |
| `could not read log file` | 提交信息文件用了 `/tmp`，改放仓库目录内 |
| `Not a valid object name origin/main` | fetch 未创建远程引用，用显式 refspec 重新 fetch |
| `CONFLICT (add/add)` | 同名文件双方都有，保留本地版本，远端版本另存备份 |
| `non-fast-forward` | 远端有新提交，先 fetch + merge，禁止强推 |
| 提交信息中文乱码 | 统一用 UTF-8 临时文件 + `git commit -F` |
| `git push` 无输出即被中断（SIGTERM） | 本环境下前台推送易被超时中断，改用后台任务执行，等 `remote: Powered by GITEE.COM` 出现即成功 |
| `timeout 120 git push` 返回 SIGTERM | 同上，`timeout` 包裹也可能被杀，直接后台跑更稳 |
| `Unable to create '.git/index.lock': File exists` | 多为上次被中断的 git 命令留下的**残留锁**。先确认无 git 进程运行（`tasklist \| grep -i git`），且锁文件为 0 字节，再 `rm -f .git/index.lock`。不要在有 git 进程运行时删锁 |

## 已确认的历史事实（避免重复劳动）

- 远端 `main` 原本只有老师账号 `neusoft_wangyao_jsj` 的提交 `a44bd70 初始提交：高级网页设计项目`。其中远端 `index1.html` 是**同学王子涵的作业**，与本地同名，已在 `762a8f5` 中合并处理。
- **当前项目结构（2026-09-14 重构后，提交 `03ae898`）**：全部页面位于仓库根目录，无子目录嵌套。

  | 文件 | 说明 |
  | --- | --- |
  | `index.html` | 课堂实践目录页（**入口页**），含 HTML 基础 / 自我介绍 / 其余模块三个分区 |
  | `introduce.html` | 自我介绍主页（由原 `introduce/index.html` 上移重命名） |
  | `form.html` | 留言表单子页面 |
  | `html_basic.html` | HTML 基础标签演示（内联 `<style>`） |
  | `html_bass.html` | HTML 基础演示（引用外部 `html_bass.css`；原名 `html_bass`，无扩展名，已补 `.html`） |
  | `css/style.css` | 自我介绍与表单页共用的外部样式 |
  | `html_bass.css` | `html_bass.html` 的外部样式 |
  | `image/` | 图片资源，含 `1.jpg`、`2.jpg`（**页面引用统一为 `image/1.jpg`**） |

- 已删除/OBSOLETE：`class.html`、`index1.html`、`index1_remote_backup.html`、`introduce/` 整个目录、`高网分数形成.jpg`、`img/` 目录（从来不存在，曾导致死链）。
- 远端同时存在 `main` 和 `master` 两个分支。**本项目统一用 `main`**，不要往 `master` 推，避免作业提交到错误分支。若需查看：`git ls-remote origin`。
- 提交前建议先跑一次死链校验（脚本已加入 `.gitignore`，不会提交）：解析所有 `href` / `src`，跳过 `http(s):`、`mailto:`、`#` 开头，其余校验文件是否存在。
- 验证推送是否成功最可靠的方法：
  ```bash
  git ls-remote origin main
  git rev-parse HEAD
  ```
  两者哈希一致即为同步完成。
